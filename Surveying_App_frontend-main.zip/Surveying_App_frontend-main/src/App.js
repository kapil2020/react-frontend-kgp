import "./App.css";
import SurveyIntro from "./components/survey_sections/general/Intro";

function App() {
  return (
    <div className="">
      <header className=""></header>
      <body>
        <SurveyIntro />
      </body>
    </div>
  );
}

export default App;
